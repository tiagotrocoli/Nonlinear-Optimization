function res = fun(x)
    res = x(1)^2 + 4*x(2)^2 + x(1)*x(2) - 2*x(1) - x(2);